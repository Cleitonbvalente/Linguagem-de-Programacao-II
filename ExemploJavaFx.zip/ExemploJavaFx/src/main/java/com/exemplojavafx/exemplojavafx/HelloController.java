package com.exemplojavafx.exemplojavafx;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import util.Alertas;

import java.io.File;
import java.time.LocalDate;
import java.util.Locale;

public class HelloController {
    @FXML
    private TextField n1;
    @FXML
    private TextField n2;
    @FXML
    private Label resultado;
    @FXML
    private ImageView imagem;
    @FXML void onImagemClicked(){
        FileChooser fc = new FileChooser();
        File file = fc.showOpenDialog(HelloApplication.getScene().getWindow());
        if(file!=null){
            imagem.setImage(new Image(file.getAbsolutePath()));
        }
    }
    @FXML
    public void onSomaClicked(){
        Locale.setDefault(Locale.US);
        try {
        float num1 = Float.parseFloat(n1.getText());
        float num2 = Float.parseFloat(n2.getText());
        float soma = num1 + num2;
        resultado.setText(String.format("%.2f",soma));
    }catch (NumberFormatException e) {
            Alertas.gerarAlerta("Erro", null, "Digite um número válido", Alert.AlertType.ERROR);
        }
    }
}
