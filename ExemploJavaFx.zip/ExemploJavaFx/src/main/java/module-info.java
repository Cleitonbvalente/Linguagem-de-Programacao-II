module com.exemplojavafx.exemplojavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.exemplojavafx.exemplojavafx to javafx.fxml;
    exports com.exemplojavafx.exemplojavafx;
}