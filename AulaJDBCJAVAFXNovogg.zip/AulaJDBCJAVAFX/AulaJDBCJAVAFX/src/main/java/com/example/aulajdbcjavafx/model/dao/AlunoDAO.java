package com.example.aulajdbcjavafx.model.dao;

import com.example.aulajdbcjavafx.model.entities.Aluno;
import com.example.aulajdbcjavafx.model.entities.Turma;
import java.util.List;

public interface AlunoDAO {
    void inserir(Aluno a);
    void atualizar(Aluno a);
    void deletar(int matricula);
    Aluno buscarPorMatricula(int matricula);
    List<Aluno> buscarTodos();

    List<Aluno> buscarPorTurma(Turma t);

}
