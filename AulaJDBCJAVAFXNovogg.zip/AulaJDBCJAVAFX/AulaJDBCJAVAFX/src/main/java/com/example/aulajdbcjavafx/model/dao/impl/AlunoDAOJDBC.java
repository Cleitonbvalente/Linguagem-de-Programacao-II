package com.example.aulajdbcjavafx.model.dao.impl;



import com.example.aulajdbcjavafx.db.DB;
import com.example.aulajdbcjavafx.model.dao.AlunoDAO;
import com.example.aulajdbcjavafx.model.entities.Aluno;
import com.example.aulajdbcjavafx.model.entities.Turma;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AlunoDAOJDBC implements AlunoDAO {

    private Connection conn;

    public AlunoDAOJDBC(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void inserir(Aluno a) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("insert into aluno(nome,cpf,dataNascimento,foto,codigoturma) values (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            st.setString(1, a.getNome());
            st.setString(2, a.getCPF());
            st.setDate(3, Date.valueOf(a.getDataNascimento()));
            st.setBytes(4, a.getFoto());
            st.setInt(5, a.getTurma().getCodigo());
            int linhas = st.executeUpdate();
            if (linhas > 0) {
                rs = st.getGeneratedKeys();
                if (rs.next()) {
                    int matricula = rs.getInt(1);
                    a.setMatricula(matricula);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }

    }

    @Override
    public void atualizar(Aluno a) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("update aluno set nome=? where matricula=?");
            st.setString(1, a.getNome());
            st.setInt(2, a.getMatricula());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public void deletar(int matricula) {
        PreparedStatement st = null;

        try {
            st = conn.prepareStatement("delete from aluno where matricula=?");
            st.setInt(1, matricula);
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public Aluno buscarPorMatricula(int matricula) {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement("select aluno.*,turma.nome as nometurma from aluno join turma on aluno.codigoTurma=turma.codigo where matricula=?");
            st.setInt(1, matricula);

            rs = st.executeQuery();
            Aluno a = new Aluno();
            if (rs.next()) {

                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("cpf"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
                Turma t = new Turma();
                t.setCodigo(rs.getInt("codigoTurma"));
                t.setNome(rs.getString("nometurma"));
                a.setTurma(t);
            }
            return a;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }


    }

    @Override
    public List<Aluno> buscarTodos() {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select aluno.*, turma.nome as nometurma from aluno join turma on aluno.codigoTurma=turma.codigo");
            rs = st.executeQuery();
            List<Aluno> alunos = new ArrayList<>();
            while (rs.next()) {
                Aluno a = new Aluno();
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("cpf"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
                Turma t = new Turma();
                t.setCodigo(rs.getInt("codigoTurma"));
                t.setNome(rs.getString("nomeTurma"));
                a.setTurma(t);
                alunos.add(a);
            }
            return alunos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }

    }

    @Override
    public List<Aluno> buscarPorTurma(Turma t) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement(
                    "SELECT aluno.*,turma.Nome as nomeTurma "
                            + "FROM aluno JOIN turma "
                            + "ON aluno.codigoTurma = turma.codigo "
                            + "WHERE codigo = ? "
                            + "ORDER BY Nome");

            st.setInt(1, t.getCodigo());

            rs = st.executeQuery();

            List<Aluno> alunos = new ArrayList<>();


            while (rs.next()) {

                Aluno a = new Aluno();
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("cpf"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
                a.setTurma(t);
                alunos.add(a);
            }
            return alunos;
        } catch (SQLException e) {
            e.getMessage();
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
        return null;
    }
}


