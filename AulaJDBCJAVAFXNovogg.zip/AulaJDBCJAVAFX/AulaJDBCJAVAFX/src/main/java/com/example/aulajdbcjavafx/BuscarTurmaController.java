package com.example.aulajdbcjavafx;

import com.example.aulajdbcjavafx.model.dao.DaoFactory;
import com.example.aulajdbcjavafx.model.entities.Turma;
import com.example.aulajdbcjavafx.util.Alertas;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class BuscarTurmaController implements Initializable {
    @FXML
    private ComboBox comboBox;
    @FXML
    private TextField textCodigo;
    @FXML
    private TextField textNome;
    @FXML
    public void onBuscarClicked(){
        Turma t = DaoFactory.createTurmaDAO().buscarPorCodigo((int)comboBox.getValue());
        textCodigo.setText(t.getCodigo()+"");
        textNome.setText(t.getNome());

    }
    @FXML
    public void onAtualizarClicked(){
        Turma t = new Turma();
        t.setCodigo(Integer.parseInt(textCodigo.getText()));
        t.setNome(textNome.getText());
        DaoFactory.createTurmaDAO().atualizar(t);
        Alertas.mostraAlerta(null, null, "Atualizado", Alert.AlertType.CONFIRMATION);

    }
    @FXML
    public void onDeletarClicked(){
        DaoFactory.createTurmaDAO().deletar((int)comboBox.getValue());
        comboBox.getItems().remove(comboBox.getValue());
        textNome.clear();
        textCodigo.clear();
        Alertas.mostraAlerta(null, null, "Deletado", Alert.AlertType.CONFIRMATION);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       List<Turma> turmas = DaoFactory.createTurmaDAO().buscarTodos();
       List<Integer> codigos = new ArrayList();
       for(Turma t:turmas){
           codigos.add(t.getCodigo());
       }

        ObservableList obs = FXCollections.observableArrayList(codigos);
       comboBox.setItems(obs);

    }
}
