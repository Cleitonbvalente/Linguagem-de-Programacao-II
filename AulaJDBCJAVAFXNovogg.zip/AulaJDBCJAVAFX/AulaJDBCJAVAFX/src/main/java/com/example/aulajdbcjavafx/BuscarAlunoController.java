package com.example.aulajdbcjavafx;

public class BuscarAlunoController {
}
