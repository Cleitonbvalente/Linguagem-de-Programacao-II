package com.example.aulajdbcjavafx.model.dao;

import com.example.aulajdbcjavafx.db.DB;
import com.example.aulajdbcjavafx.model.dao.impl.AlunoDAOJDBC;
import com.example.aulajdbcjavafx.model.dao.impl.TurmaDAOJDBC;

public class DaoFactory {

    public static AlunoDAO createAlunoDAO(){
        return new AlunoDAOJDBC(DB.getConnection());
    }

    public static TurmaDAO createTurmaDAO(){
        return new TurmaDAOJDBC(DB.getConnection());
    }

}

