package com.example.aulajdbcjavafx;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;

public class CadastrarAlunoController {
    @FXML
    private TextField nome;
    @FXML
    private TextField cpf;
    @FXML
    private DatePicker data;
    @FXML
    private ComboBox turma;
    @FXML
    private ImageView imagem;
    @FXML
    public void onCadastrarClicked() {

    }
    @FXML
    public void onImagemClicked(){
        FileChooser fc = new FileChooser();
        File file = fc.showOpenDialog(Application.getScene().getWindow());
        if(file!=null){
            imagem.setImage(new Image(file.getAbsolutePath()));
        }

    }
}
