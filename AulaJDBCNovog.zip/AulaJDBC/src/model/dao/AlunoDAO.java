package model.dao;

import model.entities.Aluno;

import java.util.List;

public interface AlunoDAO {
    void inserir(Aluno a);
    void atualizar(Aluno a);
    void deletar(int matricula);
    Aluno buscarPorMatricula(int matricula);
    List<Aluno> buscarTodos();
}
