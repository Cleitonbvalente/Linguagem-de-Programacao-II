package model.dao;

import db.DB;
import model.dao.impl.AlunoDAOJDBC;
import model.dao.impl.TurmaDAOJDBC;

public class DaoFactory {
    public static AlunoDAO createAlunoDAO() {
        return new AlunoDAOJDBC(DB.getConnection());
    }

    public static TurmaDAO createTurmaDAO() {
        return new TurmaDAOJDBC(DB.getConnection());
    }
}

