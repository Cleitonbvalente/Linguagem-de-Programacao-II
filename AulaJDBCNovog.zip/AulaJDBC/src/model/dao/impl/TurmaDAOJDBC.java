package model.dao.impl;

import db.DB;
import model.dao.TurmaDAO;
import model.entities.Turma;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TurmaDAOJDBC implements TurmaDAO {
    private Connection conn = null;

    public TurmaDAOJDBC(Connection conn){
        this.conn = conn;
    }
    @Override
    public void inserir(Turma t) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("inset into turma(nome) values (?)", Statement.RETURN_GENERATED_KEYS);
            st.setString(1, t.getNome());
            int linhas = st.executeUpdate();
            if (linhas > 0){
                rs = st.getGeneratedKeys();
                if (rs.next()) {
                    int codigo = rs.getInt(1);
                    t.setCodigo(codigo);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);

        }
    }


    @Override
    public void atualizar(Turma t) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("update turma set nome=? where matricula=?");
            st.setString(1, t.getNome());
            st.setInt(2, t.getCodigo());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public void deletar(int codigo) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("delete from turma where codigo=?");
            st.setInt(1, codigo);
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public Turma buscarPorCodigo(int codigo) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select * from turma where codigo=?");
            st.setInt(1, codigo);
            rs = st.executeQuery();
            Turma t = new Turma();
            if(rs.next()) {
                t.setCodigo(rs.getInt("Codigo"));
                t.setNome(rs.getString("Nome"));
            }
            return t;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
            DB.getConnection();
        }
    }

    @Override
    public List<Turma> buscarTodos() {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select * from turma");
            rs = st.executeQuery();
            List<Turma> turmas = new ArrayList<>();
            while(rs.next()){
                Turma t = new Turma();
                t.setCodigo(rs.getInt("Codigo"));
                t.setNome(rs.getString("Nome"));
            }
            return turmas;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }
}
