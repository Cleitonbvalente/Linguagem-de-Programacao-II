import db.DB;
import model.dao.AlunoDAO;
import model.dao.DaoFactory;
import model.dao.TurmaDAO;
import model.dao.impl.AlunoDAOJDBC;
import model.entities.Aluno;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        //Buscar por código
        AlunoDAO aluno = DaoFactory.createAlunoDAO();
        Aluno a = aluno.buscarPorMatricula(1);
        System.out.println(a.getNome());
        System.out.println(a.getTurma().getNome());

        TurmaDAO turma = DaoFactory.createTurmaDAO();
        turma.buscarPorCodigo(1);

        //Buscar por todos
        List<Aluno> alunos = aluno.buscarTodos();
        for (Aluno al: alunos){
            System.out.println(al.getNome());
            System.out.println(al.getTurma().getNome());
            System.out.println("--------");
        }
    }
}
