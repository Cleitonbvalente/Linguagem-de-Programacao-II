import model.dao.DaoFactory;
import model.dao.ProfessorDAO;
import model.entities.Professor;

public class Main {
    public static void main(String[] args) {

        Professor p = DaoFactory.createProfessorDAO().buscarPorCodigo(1);
        System.out.println(p.getNome());

    }
}
