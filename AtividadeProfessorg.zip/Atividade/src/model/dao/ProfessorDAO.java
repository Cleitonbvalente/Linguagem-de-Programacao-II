package model.dao;

import model.entities.Professor;

import java.util.List;

public interface ProfessorDAO {
    void inserir(Professor p);
    void atualizar(Professor p);
    void deletar(int codigo);
    Professor buscarPorCodigo(int codigo);
    List<Professor> buscarTodos();
}
