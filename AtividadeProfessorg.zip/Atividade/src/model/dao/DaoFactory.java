package model.dao;

import db.DB;
import model.dao.impl.ProfessorDAOJDBC;

public class DaoFactory {
    public static ProfessorDAO createProfessorDAO(){
        return new ProfessorDAOJDBC(DB.getConnection());
    }
}
