package model.dao.impl;

import db.DB;
import model.dao.ProfessorDAO;
import model.entities.Professor;

import java.sql.*;
import java.util.List;

public class ProfessorDAOJDBC implements ProfessorDAO {
    private Connection conn;

    public ProfessorDAOJDBC(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void inserir(Professor p) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("insert into professor(nome) values(?)", Statement.RETURN_GENERATED_KEYS);
            st.setString(1,p.getNome());
            int linhas = st.executeUpdate();
            if(linhas>0){
                rs = st.getGeneratedKeys();
                if(rs.next()){
                    p.setCodigo(rs.getInt("codigo"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeResultSet(rs);
            DB.closeStatement(st);
        }

    }

    @Override
    public void atualizar(Professor p) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("update professor set nome=? where codigo=?");
            st.setString(1,p.getNome());
            st.setInt(2, p.getCodigo());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public void deletar(int codigo) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("delete from professor where codigo=?");
            st.setInt(1, codigo);
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public Professor buscarPorCodigo(int codigo) {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement("select * from professor where codigo=?");
            st.setInt(1, codigo);
            rs = st.executeQuery();
            if (rs.next()) {
                Professor p = new Professor();
                p.setCodigo(rs.getInt("codigo"));
                p.setNome(rs.getString("nome"));
                return  p;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeResultSet(rs);
            DB.closeStatement(st);
        }
        return null;
    }

    @Override
    public List<Professor> buscarTodos() {
        return null;
    }
}
