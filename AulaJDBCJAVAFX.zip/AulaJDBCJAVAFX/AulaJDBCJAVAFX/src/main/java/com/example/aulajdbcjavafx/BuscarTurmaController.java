package com.example.aulajdbcjavafx;

import com.example.aulajdbcjavafx.model.dao.DaoFactory;
import com.example.aulajdbcjavafx.model.entities.Turma;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class BuscarTurmaController implements Initializable {
    @FXML
    private ComboBox comboBox;
    @FXML
    private TextField textCodigo;
    @FXML
    private TextField textNome;
    @FXML
    public void onBuscarClicked(){

    }
    @FXML
    public void onAtualizarClicked(){

    }
    @FXML
    public void onDeletarClicked(){

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       List<Turma> turmas = DaoFactory.createTurmaDAO().buscarTodos();
       List<Integer> codigos = new ArrayList();
       for(Turma t:turmas){
           codigos.add(t.getCodigo());
       }

        ObservableList obs = FXCollections.observableArrayList(codigos);
       comboBox.setItems(obs);

    }
}
