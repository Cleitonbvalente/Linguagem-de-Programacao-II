package model.dao.impl;

import db.DB;
import model.dao.AlunoDAO;
import model.entities.Aluno;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAOJDBC implements AlunoDAO {
    private Connection conn;

    public AlunoDAOJDBC(Connection conn){
        this.conn = conn;
    }
    @Override
    public void inserir(Aluno a) {

    }

    @Override
    public void atualizar(Aluno a) {

    }

    @Override
    public void deletar(int matricula) {

    }

    @Override
    public Aluno buscarPorMatricula(int matricula) {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement(("select * from aluno where matricula=?"));
            st.setInt(1, matricula);
            rs = st.executeQuery();
            Aluno a = new Aluno();
            if(rs.next()) {
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("CPF"));
                a.setNome(rs.getString("Nome"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
            }
            return a;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);
            DB.getConnection();
        }
    }

    @Override
    public List<Aluno> buscarTodos() {

        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select * from aluno");
            rs = st.executeQuery();
            List<Aluno> alunos = new ArrayList<>();
            while (rs.next()){
                Aluno a = new Aluno();
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("CPF"));
                a.setNome(rs.getString("Nome"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
                alunos.add(a);
            }
            return alunos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);
            DB.closeConnection();
        }
    }
}
