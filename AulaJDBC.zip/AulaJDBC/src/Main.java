import db.DB;
import model.dao.AlunoDAO;
import model.dao.impl.AlunoDAOJDBC;
import model.entities.Aluno;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        AlunoDAO a = new AlunoDAOJDBC(DB.getConnection());
        Aluno aluno = a.buscarPorMatricula(1);
        System.out.println(aluno.getNome());
    }
}
