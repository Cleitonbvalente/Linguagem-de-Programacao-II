import db.DB;
import model.dao.AlunoDAO;
import model.dao.DaoFactory;
import model.dao.TurmaDAO;
import model.dao.impl.AlunoDAOJDBC;
import model.entities.Aluno;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        AlunoDAO aluno = DaoFactory.createAlunoDAO();
        aluno.buscarPorMatricula(1);

        TurmaDAO turma = DaoFactory.createTurmaDAO();
        turma.buscarPorCodigo(1);
        
    }
}
