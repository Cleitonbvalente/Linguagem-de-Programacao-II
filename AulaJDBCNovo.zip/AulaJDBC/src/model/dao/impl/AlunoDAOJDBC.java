package model.dao.impl;

import db.DB;
import model.dao.AlunoDAO;
import model.entities.Aluno;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAOJDBC implements AlunoDAO {
    private Connection conn;

    public AlunoDAOJDBC(Connection conn){
        this.conn = conn;
    }
    @Override
    public void inserir(Aluno a) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("insert into aluno(nome, cpf, dataNascimento,foto) values (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            st.setString(1, a.getNome());
            st.setString(2, a.getCPF());
            st.setDate(3, Date.valueOf(a.getDataNascimento()));
            st.setBytes(4, a.getFoto());
            int linhas = st.executeUpdate();
            if(linhas > 0){
                rs = st.getGeneratedKeys();
                if(rs.next()){
                    int matricula = rs.getInt(1);
                    a.setMatricula(matricula);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }

    }

    @Override
    public void atualizar(Aluno a) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("update aluno set nome=? where matricula=?");
            st.setString(1, a.getNome());
            st.setInt(2,a.getMatricula());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public void deletar(int matricula) {
        PreparedStatement st = null;

        try {
            st = conn.prepareStatement("delete from aluno where matricula=?");
            st.setInt(1, matricula);
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
        }

    }

    @Override
    public Aluno buscarPorMatricula(int matricula) {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement(("select * from aluno where matricula=?"));
            st.setInt(1, matricula);
            rs = st.executeQuery();
            Aluno a = new Aluno();
            if(rs.next()) {
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("CPF"));
                a.setNome(rs.getString("Nome"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
            }
            return a;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);
            DB.getConnection();
        }
    }

    @Override
    public List<Aluno> buscarTodos() {

        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select * from aluno");
            rs = st.executeQuery();
            List<Aluno> alunos = new ArrayList<>();
            while (rs.next()){
                Aluno a = new Aluno();
                a.setMatricula(rs.getInt("matricula"));
                a.setNome(rs.getString("nome"));
                a.setCPF(rs.getString("CPF"));
                a.setNome(rs.getString("Nome"));
                a.setDataNascimento(rs.getDate("dataNascimento").toLocalDate());
                a.setFoto(rs.getBytes("foto"));
                alunos.add(a);
            }
            return alunos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }
}
