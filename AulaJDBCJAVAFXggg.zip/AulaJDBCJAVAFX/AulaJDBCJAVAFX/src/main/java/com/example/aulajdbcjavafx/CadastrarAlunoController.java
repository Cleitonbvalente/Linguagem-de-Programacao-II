package com.example.aulajdbcjavafx;

import com.example.aulajdbcjavafx.model.dao.DaoFactory;
import com.example.aulajdbcjavafx.model.entities.Aluno;
import com.example.aulajdbcjavafx.model.entities.Turma;
import com.example.aulajdbcjavafx.util.Alertas;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CadastrarAlunoController implements Initializable {
    @FXML
    private TextField nome;
    @FXML
    private TextField cpf;
    @FXML
    private DatePicker data;
    @FXML
    private ComboBox turma;
    @FXML
    private ImageView imagem;
    private File file;
    @FXML
    public void onCadastrarClicked() {
        Aluno a = new Aluno();
        a.setNome(nome.getText());
        a.setCPF(cpf.getText());
        a.setDataNascimento(data.getValue());
        Turma t = new Turma();
        t = DaoFactory.createTurmaDAO().buscarPorCodigo((int)turma.getValue());
        a.setTurma(t);
        byte[] filebytes = new byte[0];
        try {
            filebytes = Files.readAllBytes(file.toPath());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        a.setFoto(filebytes);
        DaoFactory.createAlunoDAO().inserir(a);
        Alertas.mostraAlerta(null, null, "Cadastrado", Alert.AlertType.CONFIRMATION);

    }
    @FXML
    public void onImagemClicked(){
        FileChooser fc = new FileChooser();
        file = fc.showOpenDialog(Application.getScene().getWindow());
        if(file!=null){
            imagem.setImage(new Image(file.getAbsolutePath()));
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<Turma> lista = DaoFactory.createTurmaDAO().buscarTodos();
        List<Integer> codigos = new ArrayList<>();
        for(Turma t:lista){
            codigos.add(t.getCodigo());
        }

        ObservableList obs = FXCollections.observableArrayList(codigos);
        turma.setItems(obs);
    }
}
