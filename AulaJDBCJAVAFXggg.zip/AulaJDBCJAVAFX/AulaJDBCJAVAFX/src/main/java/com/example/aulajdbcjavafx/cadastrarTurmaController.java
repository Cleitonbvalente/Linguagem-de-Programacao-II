package com.example.aulajdbcjavafx;

import com.example.aulajdbcjavafx.model.dao.DaoFactory;
import com.example.aulajdbcjavafx.model.entities.Turma;
import com.example.aulajdbcjavafx.util.Alertas;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class cadastrarTurmaController {
    @FXML
    private TextField nome;

    @FXML
    public void onCadastrarClicked(){
        Turma t = new Turma();
        t.setNome(nome.getText());
        DaoFactory.createTurmaDAO().inserir(t);
        Alertas.mostraAlerta(null, null,"Cadastrado com sucesso", Alert.AlertType.CONFIRMATION);

    }
}
