package com.example.aulajdbcjavafx;

import com.example.aulajdbcjavafx.model.dao.DaoFactory;
import com.example.aulajdbcjavafx.model.entities.Aluno;
import com.example.aulajdbcjavafx.model.entities.Turma;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class BuscarAlunoController implements Initializable {
    @FXML
    private TextField matricula;
    @FXML
    private TextField nome;
    @FXML
    private TextField cpf;
    @FXML
    private DatePicker data;
    @FXML
    private ComboBox turma;
    @FXML
    private ImageView imagem;
    File file;
    @FXML
    public void onImagemClicked(){
        FileChooser fc = new FileChooser();
        file = fc.showOpenDialog(Application.getScene().getWindow());
        if(file!=null){
            imagem.setImage(new Image(file.getAbsolutePath()));
        }

    }
    @FXML
    public void onBuscarClicked(){
        Aluno a = new Aluno();
        int mat = Integer.parseInt(matricula.getText());
        a = DaoFactory.createAlunoDAO().buscarPorMatricula(mat);
        nome.setText(a.getNome());
        cpf.setText(a.getCPF());
        data.setValue(a.getDataNascimento());
        turma.setValue(a.getTurma().getCodigo());
        if(a.getFoto()!=null){
            Image image = new Image(new ByteArrayInputStream(a.getFoto()));
            imagem.setImage(image);
        }
    }
    @FXML
    public void onAtualizarClicked() {
        if (matricula.getText().isEmpty()) {
            System.out.println("Digite a matricula para atualizar: ");
            return;
        }
        Aluno aluno = DaoFactory.createAlunoDAO().buscarPorMatricula(Integer.parseInt(matricula.getText()));
        if (aluno == null) {
            System.out.println("Aluno não encontrado");
            return;
        }
        aluno.setNome(nome.getText());
        aluno.setCPF(cpf.getText());
        aluno.setDataNascimento(data.getValue());
        aluno.setTurma((Turma) turma.getValue());

        DaoFactory.createAlunoDAO().atualizar(aluno);
        System.out.println("Aluno atualizado com sucesso");
    }

    @FXML
    public void onDeletarClicked(){

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<Turma> lista = DaoFactory.createTurmaDAO().buscarTodos();
        List<Integer> codigos = new ArrayList<>();
        for(Turma t: lista){
            codigos.add(t.getCodigo());
        }
        ObservableList obs = FXCollections.observableArrayList(codigos);
        turma.setValue(obs);
    }
}
