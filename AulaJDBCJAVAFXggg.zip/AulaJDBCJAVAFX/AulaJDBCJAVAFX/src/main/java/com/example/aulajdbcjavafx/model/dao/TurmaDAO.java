package com.example.aulajdbcjavafx.model.dao;

import com.example.aulajdbcjavafx.model.entities.Turma;

import java.util.List;

public interface TurmaDAO {
    void inserir(Turma t);
    void atualizar(Turma t);
    void deletar(int codigo);
    Turma buscarPorCodigo(int codigo);
    List<Turma> buscarTodos();
}
