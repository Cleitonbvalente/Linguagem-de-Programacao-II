package com.example.aulajdbcjavafx.model.dao.impl;



import com.example.aulajdbcjavafx.db.DB;
import com.example.aulajdbcjavafx.model.dao.TurmaDAO;
import com.example.aulajdbcjavafx.model.entities.Turma;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TurmaDAOJDBC implements TurmaDAO {
    private Connection conn;

    public TurmaDAOJDBC(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void inserir(Turma t) {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("insert into turma(nome) values (?)", Statement.RETURN_GENERATED_KEYS);
            st.setString(1,t.getNome());
            int linhas = st.executeUpdate();
            if (linhas>0){
                rs = st.getGeneratedKeys();
                if(rs.next()){
                    t.setCodigo(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);

        }


    }

    @Override
    public void atualizar(Turma t) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("update turma set nome=? where codigo=?");
            st.setString(1,t.getNome());
            st.setInt(2,t.getCodigo());
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
        }

    }

    @Override
    public void deletar(int codigo) {
        PreparedStatement st = null;

        try {
            st = conn.prepareStatement("delete from turma where codigo=?");
            st.setInt(1,codigo);
            st.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
        }
    }

    @Override
    public Turma buscarPorCodigo(int codigo) {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement("select * from turma where codigo=?");
            st.setInt(1, codigo);

            rs = st.executeQuery();
            Turma t = new Turma();
            if (rs.next()) {

                t.setCodigo(rs.getInt("codigo"));
                t.setNome(rs.getString("nome"));
            }
            return t;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }

    @Override
    public List<Turma> buscarTodos() {
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            st = conn.prepareStatement("select * from turma");
            rs = st.executeQuery();
            List<Turma> turmas = new ArrayList<>();
            while(rs.next()){
                Turma t = new Turma();
                t.setCodigo(rs.getInt("codigo"));
                t.setNome(rs.getString("nome"));
                turmas.add(t);
            }
            return turmas;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            DB.closeStatement(st);
            DB.closeResultSet(rs);
        }
    }
}

